import os
import sys


class SymbolTable:
    """This is the Symbol Table class that init the first address to 16 and contains
a dictionary of the  popular symbols and method that treat  the symbol """

    def __init__(self):
        self.__next_symbol_address = 16
        self.__symbols = {
            "R0": 0,
            "R1": 1,
            "R2": 2,
            "R3": 3,
            "R4": 4,
            "R5": 5,
            "R6": 6,
            "R7": 7,
            "R8": 8,
            "R9": 9,
            "R10": 10,
            "R11": 11,
            "R12": 12,
            "R13": 13,
            "R14": 14,
            "R15": 15,
            "SP": 0,
            "LCL": 1,
            "ARG": 2,
            "THIS": 3,
            "THAT": 4,
            "SCREEN": 16384,
            "KBD": 24576
        }

    def is_symbol_exist(self, entry):
        """This method check if symbol exist in dictionary"""
        return self.__symbols.__contains__(entry)

    def get_symbol(self, entry):
        """This method call to is_symbol_exist and return its value else return none"""
        if self.is_symbol_exist(entry):
            return self.__symbols[entry]
        return None

    def add_label(self, symbol_key, symbol_value):
        """This method get key and value of label and if not already exist add them to the dictionary"""
        if not self.is_symbol_exist(symbol_key):
            self.__symbols[symbol_key] = symbol_value
            return symbol_value
        return None

    def add_symbol(self, symbol_key):
        """This method get key of symbol and if not already exist add the key with the current address"""
        if not self.is_symbol_exist(symbol_key):
            self.__symbols[symbol_key] = self.__next_symbol_address
            self.__next_symbol_address += 1
            return self.__next_symbol_address - 1


class Parser:
    """This is the Parser class that parser the instructions to a_instruction and c_instruction for
        convert them to binary  by the dest,comp and jump dictionary"""

    def __init__(self):
        self.instructions = []
        self.__symbols_table = SymbolTable()

    @staticmethod
    def dest(dest):
        """Dest dictionary"""
        return {
            "null": "000",
            "M": "001",
            "D": "010",
            "MD": "011",
            "A": "100",
            "AM": "101",
            "AD": "110",
            "AMD": "111"
        }[dest]

    @staticmethod
    def comp(comp):
        """Comp dictionary"""
        return {
            "M": "1110000",
            "!M": "1110001",
            "-M": "1110011",
            "M+1": "1110111",
            "M-1": "1110010",
            "D+M": "1000010",
            "D-M": "1010011",
            "M-D": "1000111",
            "D&M": "1000000",
            "D|M": "1010101",
            "0": "0101010",
            "1": "0111111",
            "-1": "0111010",
            "D": "0001100",
            "A": "0110000",
            "!D": "0001101",
            "!A": "0110001",
            "-D": "0001111",
            "-A": "0110011",
            "D+1": "0011111",
            "A+1": "0110111",
            "D-1": "0001110",
            "A-1": "0110010",
            "D+A": "0000010",
            "D-A": "0010011",
            "A-D": "0000111",
            "D&A": "0000000",
            "D|A": "0010101"
        }[comp]


    @staticmethod
    def jump(jump):
        """Jump dictionary"""
        return {
            "null": "000",
            "JGT": "001",
            "JEQ": "010",
            "JGE": "011",
            "JLT": "100",
            "JNE": "101",
            "JLE": "110",
            "JMP": "111"
        }[jump]

    @staticmethod
    def is_white_line_or_comment(line):
        """This method check if the current instruction is comment or white line"""
        return line == '\n' or line[0] == "/"

    @staticmethod
    def is_label(line):
        """This method check if the current instruction is label_instruction"""
        return line[0] == "("

    def handle_label_decleration(self, label, line_number):
        """This method handle label in declaration by add_label method"""
        self.__symbols_table.add_label(label, line_number)

    def preproccess_file(self, file_path):
        """ This method get the file_path and open the asm file and copy the instructions
            to instructions array  after split the comment after the instructions and delete the spaces"""
        with open(file_path, "r") as asm_file:
            for line in asm_file:
                if not self.is_white_line_or_comment(line):
                    line = line.split("\n")[0].split("//")[0].replace(" ", "")
                    if not self.is_label(line):
                        self.instructions.append(line)
                    else:
                        self.handle_label_decleration(line.split("(")[1].split(")")[0], len(self.instructions))

    def handle_label_command(self):
        """This method check every instruction if its label_instruction and get is value
            if its already exist else add the label to the dictionary"""
        for i in range(len(self.instructions)):
            if self.instructions[i][0] == "@" and self.instructions[i][1].isalpha():
                symbol_value = self.__symbols_table.get_symbol(self.instructions[i].split("@")[1])
                if symbol_value is None:
                    symbol_value = self.__symbols_table.add_symbol(self.instructions[i].split("@")[1])
                self.instructions[i] = "@" + str(symbol_value)

    @staticmethod
    def a_instruction(instruction):
        """This method convert a_instruction to binary with out the '@'"""
        return str(format(int(instruction[1::]), '016b'))

    def c_instruction(self, instruction):
        """This method parse the c_instruction to jump,dest and comp by split the
            instruction by '=' and ';' chars and convert the instruction to binary"""
        jump = "null"
        dest = "null"
        equals_index = instruction.find("=")
        semicolon_index = instruction.find(";")
        if semicolon_index != -1:
            jump = instruction[semicolon_index + 1::]
            if equals_index != -1:
                dest = instruction[0:equals_index]
                comp = instruction[equals_index + 1::semicolon_index]
            else:
                comp = instruction[0:semicolon_index]
        else:
            dest = instruction[0:equals_index]
            comp = instruction[equals_index + 1::]
        return "111" + self.comp(comp) + self.dest(dest) + self.jump(jump)

    def command_type(self, instruction):
        """This method check the type of instruction send the current instruction to the suitable function"""
        if instruction[0] == '@':
            return self.a_instruction(instruction)
        else:
            return self.c_instruction(instruction)

    def parse_instructions(self, path_name):
        """This method write the parsed instruction to the hack file"""
        with open(path_name, "w") as hack_file:
            for instruction in self.instructions:
                hack_file.writelines(self.command_type(instruction) + '\n')

    def parse(self, file_path):
        """This method get the file_path and activate the mains methods"""
        self.preproccess_file(file_path)
        self.handle_label_command()
        base = os.path.basename(file_path)
        self.parse_instructions(file_path.replace(base, "") + os.path.splitext(base)[0] + ".hack")


if __name__ == '__main__':
    file = sys.argv[1]
    parser = Parser()
    parser.parse(file)
